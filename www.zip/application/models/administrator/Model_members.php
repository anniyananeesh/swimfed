<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Model_members extends MY_model
{

    protected $table = TBL_MEMBERS;
    protected $primary_key = 'id';

}
