<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Model_visa_images extends MY_model {

    protected $table = TBL_VISA_IMAGES;
    protected $primary_key = 'id';
}
