<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Model_sponsor_images extends MY_model {

    protected $table = TBL_SPONSOR_IMAGES;
    protected $primary_key = 'id';
}
